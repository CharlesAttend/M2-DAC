Je trouve les TME d'AMAL vraiment passionnants, surtout pour le débogage. Mais j'ai saturé des RNN vers la fin.

Concernant le TME4, exercice 4, j'ai rencontré des difficultés avec la génération et fini par utiliser le code de quelqu'un d'autre. Malgré une faible perte lors de l'apprentissage, le code génère le même mot en boucle. Je n'ai pas pris le temps de déboguer davantage.

Pour le TME5, je ne l'ai pas revu depuis la session en classe. J'étais dépité d'apprendre qu'il fallait avoir terminé le précédent pour avancer. Le problème est que je dois réutiliser la fonction de génération, mais je ne suis même pas sûr de son bon fonctionnement.

Heureusement, le TME6 s'est bien passé. C'était un peu compliqué, mais le modèle traduit correctement. Le code est propre. J'ai fait quelques tests, et voici les [résultats sur W & B](https://wandb.ai/charlesattend_/amal).

En fait, j'ai terminé le TME6 avant de revenir sur les TME4 et 5. Ce qui fait qu'il fallait se réadapter aux données différentes et refaire tout à la main. J'ai switch sur d'autre truc à faire à la place.

Je n'ai pas réussi à maintenir la qualité habituelle de mes rendus. J'espère que cela n'influencera pas négativement votre jugement.